#include "selectlabel.h"

SelectLabel::SelectLabel()
{
    SelectLabel::SelectLabel(QString Path,int width, int height):
        mwidth(width), mheight(height), SelectBoxImgPath(Path){}

    int SelectLabel::GetX() const     //获取横坐标
    {
        return mx;
    }
    int SelectLabel::GetY() const    //获取横坐标
    {
        return my;
    }
    int SelectLabel::GetWidth() const //获取宽
    {
        return mwidth;
    }
    int SelectLabel::GetHeight() const //获取高
    {
        return mheight;
    }

    QString SelectLabel::GetImgPath() const    //返回选择框图片路径
    {
        return SelectBoxImgPath;
    }

    //获取显示状态
    bool SelectLabel::GetDisplay() const
    {
        return display;
    }

    //设置显示状态
    void SelectLabel::SetDisplay(const bool SetPlay)
    {
        display = SetPlay;
    }

    //选中防御塔
    void SelectLabel::CheckTower(int x, int y)
    {
        //确定选择框的位置
        mx = x - 95, my = y - 95;

        //确定子按钮的位置
        SubBtn[0].SubX = mx + 106, SubBtn[0].SubY = my + 14;
        SubBtn[0].SubImgPath = QString(":/image/BuyGreenBottle.png");

        SubBtn[1].SubX = mx + 14, SubBtn[1].SubY = my + 106;
        SubBtn[1].SubImgPath = QString(":/image/BuyFireBottle.png");

        SubBtn[2].SubX = mx + 202, SubBtn[2].SubY = my + 106;
        SubBtn[2].SubImgPath = QString(":/image/BrightCannon.png");

        SubBtn[3].SubX = mx + 106, SubBtn[3].SubY = my + 190;
        SubBtn[3].SubImgPath = QString(":/image/cannon.png");

        display = true; //显示状态设为真
    }

    //获取子按钮结构数组
    SubbtnStr* SelectLabel::GetSelSubBtn()
    {
        return SubBtn;
    }

}
