#ifndef CANNON2_H
#define CANNON2_H

#include "defensetowerparent.h"
//加农炮2号防御塔类
class Cannon2:public DefenseTowerParent
{
public:
    Cannon2(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // CANNON2_H



