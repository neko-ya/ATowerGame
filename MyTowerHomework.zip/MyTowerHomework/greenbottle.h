#ifndef GREENBOTTLE_H
#define GREENBOTTLE_H

#include "defensetowerparent.h"

//绿色炮塔类，继承防御塔父类
class GreenBottle: public DefenseTowerParent
{
protected:

public:
    GreenBottle(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};


#endif // GREENBOTTLE_H


