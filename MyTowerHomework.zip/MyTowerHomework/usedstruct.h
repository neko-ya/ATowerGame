#ifndef USEDSTRUCT_H
#define USEDSTRUCT_H


#include <QString>

//选择框子按钮结构
struct SubbtnStr
{
    int SubX;           //子按钮相对选择框的横坐标
    int SubY;           //纵坐标
    int SubWidth = 40;  //子按钮宽
    int SubHeight = 40; //高
    QString SubImgPath; //子按钮的图片路径
};

//坐标结构
struct CoordStr
{
    int x;
    int y;

    CoordStr(int x1, int y1) : x(x1), y(y1) {}
};

//子弹结构
struct BulletStr
{
    CoordStr coord;       //子弹坐标
    int k = 0, b = 0;   //用于计算出子弹路径函数
    bool diretflag = false;   //移动方向标识

    BulletStr(CoordStr fcoord) : coord(fcoord) {}

    int GetX()  const
    {
        return coord.x;
    }

    int GetY() const
    {
        return coord.y;
    }
};

#endif // USEDSTRUCT_H

