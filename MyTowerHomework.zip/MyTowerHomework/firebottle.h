#ifndef FIREBOTTLE_H
#define FIREBOTTLE_H
#include "defensetowerparent.h"

//火炮塔类，继承防御塔父类
class FireBottle : public DefeTowerParent
{
protected:

public:
    FireBottle(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // FIREBOTTLE_H
