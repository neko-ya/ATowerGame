#ifndef CANNON1_H
#define CANNON1_H
#include "defensetowerparent.h"
//加农炮1防御塔类
class Cannon1: public DefenseTowerParent
{
protected:

public:
    Cannon1(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // CANNON1_H

