#include "firststart.h"
#include "ui_firststart.h"
#include<QPainter>
#include<QPushButton>


FirstStart::FirstStart(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FirstStart)
{
    ui->setupUi(this);
    setWindowTitle("Start the TowerGame!");
    //num of round
    const int Num=2;
    //button array
    QPushButton* btnarr[Num] = {ui->pushButton, ui->pushButton_2, ui->pushButton_3};

    for (int i = 0; i < Num; i++)
        connect(btnarr[i], &QPushButton::clicked, [=]() //监听所有按钮点击
        {
            MainWindow *mainwindow = new MainWindow(i); //向游戏类中传入对应关卡编号
            mainwindow->show();     //显示窗口
        });

}

FirstStart::~FirstStart()
{
    delete ui;
}



