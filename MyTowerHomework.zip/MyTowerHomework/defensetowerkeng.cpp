
#include "defensetowerkeng.h"

//构造
DefenseTowerKeng::DefenseTowerKeng(int x, int y, int width, int height)
    : mx(x), my(y), mwidth(width), mheight(height) {}

int DefenseTowerKeng::GetX() const     //获取横坐标
{
    return mx;
}

int DefenseTowerKeng::GetY() const     //获取横坐标
{
    return my;
}

int DefenseTowerKeng::GetWidth() const //获取宽
{
    return mwidth;
}

int DefenseTowerKeng::GetHeight() const //获取高
{
    return mheight;
}

